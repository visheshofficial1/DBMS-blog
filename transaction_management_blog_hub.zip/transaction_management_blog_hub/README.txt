TRANSACTION LAB — DBMS BLOG DASHBOARD
=====================================

CONTENTS
- index.html: Main dashboard with all four blog cards and a search box.
- blogs/cab-booking.html
- blogs/hospital-appointments.html
- blogs/hotel-reservations.html
- blogs/university-examination.html

RUN LOCALLY
1. Extract this ZIP file.
2. Open index.html in a web browser.
3. Click any card's "Read this blog" link to open that full blog.

PUBLISH AS ONE PUBLIC LINK WITH GITHUB PAGES
1. Sign in to GitHub and create a new public repository, for example:
   transaction-lab
2. Upload the contents of this folder (index.html and the blogs folder)
   to the repository's root. Do not upload only the ZIP.
3. Open the repository's Settings > Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Choose branch "main" and folder "/ (root)", then Save.
6. Wait for GitHub Pages to publish. The repository's Pages screen will show
   the public website URL. Share that one URL; it opens the dashboard.
7. Keep the blogs folder alongside index.html so the card links work.

The original four blog HTML files are preserved as separate pages, so their
interactive features and individual styling remain intact.
